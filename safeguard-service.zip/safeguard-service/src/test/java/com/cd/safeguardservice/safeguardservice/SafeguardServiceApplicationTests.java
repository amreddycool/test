package com.cd.safeguardservice.safeguardservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SafeguardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
