package com.cd.safeguardservice.safeguardservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafeguardServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SafeguardServiceApplication.class, args);
	}

}
